import os
import re

class processor:
    def __init__(self, base_dir=None):
        self.macros = {}
        self.base_dir = base_dir or os.getcwd()

    def process_file(self, filename):
        if not os.path.isabs(filename):
            filename = os.path.join(self.base_dir, filename)
        if not os.path.exists(filename):
            raise FileNotFoundError(f"Arquivo {filename} não encontrado.")
        with open(filename, "r") as f:
            lines = f.readlines()
        old_base = self.base_dir
        self.base_dir = os.path.dirname(os.path.abspath(filename))
        result = self.process_lines(lines)
        self.base_dir = old_base
        return result

    def resolve_system_include(self, header_name):
        paths = [
            f"/usr/include/{header_name}",
            f"/usr/include/banana/{header_name}",
        ]
        for path in paths:
            if os.path.exists(path):
                with open(path, "r") as f:
                    return f.readlines()
        raise FileNotFoundError(
            f"Header <{header_name}> não encontrado em /usr/include nem /usr/include/banana"
        )

    def process_lines(self, lines):
        output = []
        skip_stack = []  # cada entrada: True = ignorar bloco

        for line in lines:
            stripped = line.strip()

            # ── Diretivas ────────────────────────────────────────────────────

            if stripped.startswith("%define"):
                if skip_stack and skip_stack[-1]:
                    continue
                parts = stripped.split(maxsplit=2)
                key   = parts[1] if len(parts) > 1 else ""
                value = parts[2] if len(parts) > 2 else ""
                self.macros[key] = value
                continue

            elif stripped.startswith("%undef"):
                if skip_stack and skip_stack[-1]:
                    continue
                parts = stripped.split()
                if len(parts) > 1:
                    self.macros.pop(parts[1], None)
                continue

            elif stripped.startswith("%ifdef"):
                parts = stripped.split()
                key = parts[1] if len(parts) > 1 else ""
                skip_stack.append(key not in self.macros)
                continue

            elif stripped.startswith("%ifndef"):
                parts = stripped.split()
                key = parts[1] if len(parts) > 1 else ""
                skip_stack.append(key in self.macros)
                continue

            elif stripped.startswith("%else"):
                if not skip_stack:
                    raise SyntaxError("%else sem bloco correspondente.")
                skip_stack[-1] = not skip_stack[-1]
                continue

            elif stripped.startswith("%endif"):
                if not skip_stack:
                    raise SyntaxError("%endif sem bloco correspondente.")
                skip_stack.pop()
                continue

            elif stripped.startswith("%include"):
                if skip_stack and skip_stack[-1]:
                    continue
                rest = stripped[len("%include"):].strip()
                if rest.startswith("<") and rest.endswith(">"):
                    header = rest[1:-1]
                    included_lines = self.resolve_system_include(header)
                    output.extend(self.process_lines(included_lines))
                else:
                    local_file = rest.strip('"').strip("'")
                    output.extend(self.process_file(local_file))
                continue

            elif stripped.startswith("%error"):
                if skip_stack and skip_stack[-1]:
                    continue
                msg = stripped[len("%error"):].strip()
                raise SyntaxError(f"%error: {msg}")

            elif stripped.startswith("%warning"):
                if skip_stack and skip_stack[-1]:
                    continue
                msg = stripped[len("%warning"):].strip()
                import sys
                print(f"[preprocess warning] {msg}", file=sys.stderr)
                continue

            # ── Bloco ignorado ───────────────────────────────────────────────

            if skip_stack and skip_stack[-1]:
                continue

            # ── Substituição de macros (palavra inteira) ─────────────────────

            for key, value in self.macros.items():
                line = re.sub(r'\b' + re.escape(key) + r'\b', value, line)

            output.append(line)

        if skip_stack:
            raise SyntaxError(f"Bloco %ifdef/%ifndef não fechado ({len(skip_stack)} aberto(s)).")

        return output
