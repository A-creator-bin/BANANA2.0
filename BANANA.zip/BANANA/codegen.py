"""
BANANA Code Generator
Emits C code from the AST (acts as our LLVM IR → native code pipeline)
The generated C is compiled with GCC to produce native binaries.
"""

from ast_nodes import *
from io import StringIO


class CodegenError(Exception):
    def __init__(self, msg, line=0):
        super().__init__(f"[CodegenError] Line {line}: {msg}")


class Codegen:
    def __init__(self):
        self.out = StringIO()
        self.indent = 0
        self.tmp_counter = 0
        self.string_literals: list = []   # (id, value)
        self.str_id = 0

    # ─── Output helpers ───────────────────────────────────────────────────────

    def emit(self, s):
        self.out.write(s)

    def emitln(self, s=''):
        self.out.write(('    ' * self.indent) + s + '\n')

    def emit_raw(self, s):
        self.out.write(s)

    def tmp(self):
        self.tmp_counter += 1
        return f'_bn_tmp{self.tmp_counter}'

    def str_lit_id(self, val: str) -> str:
        sid = f'_bn_str{self.str_id}'
        self.str_id += 1
        self.string_literals.append((sid, val))
        return sid

    # ─── Type → C type ────────────────────────────────────────────────────────

    def c_type(self, t) -> str:
        if isinstance(t, TypeInt):   return 'long long'
        if isinstance(t, TypeFloat): return 'double'
        if isinstance(t, TypeChar):  return 'char'
        if isinstance(t, TypeVoid):  return 'void'
        if isinstance(t, TypeArr):
            if isinstance(t.elem_type, TypeChar):
                return 'char*'
            return f'{self.c_type(t.elem_type)}*'
        return 'void*'

    def c_type_decl(self, t, name: str) -> str:
        """For array declarations with size."""
        if isinstance(t, TypeArr) and t.size is not None:
            inner = self.c_type(t.elem_type)
            size_expr = self.gen_expr(t.size)
            return f'{inner} {name}[{size_expr}]'
        return f'{self.c_type(t)} {name}'

    # ─── Program ──────────────────────────────────────────────────────────────

    def generate(self, prog: Program) -> str:
        # Preamble
        header = StringIO()
        header.write('#include <stdio.h>\n')
        header.write('#include <stdlib.h>\n')
        header.write('#include <string.h>\n')
        # Built-in runtime functions
        header.write('/* BANANA Runtime */\n')
        header.write('static void print_int(long long v)   { printf("%lld\\n", v); }\n')
        header.write('static void print_float(double v)    { printf("%g\\n", v); }\n')
        header.write('static void print_char(char v)       { printf("%c\\n", v); }\n')
        header.write('static void print_str(char* v)       { printf("%s\\n", v ? v : "(null)"); }\n')
        header.write('static double int_to_float(long long v) { return (double)v; }\n')
        header.write('static long long float_to_int(double v) { return (long long)v; }\n')
        header.write(
            'static char* python(char* code) {\n'
            '    char cmd[4096];\n'
            '    snprintf(cmd, sizeof(cmd), "python3 -I -S -E -c -c \\"%s\\"", code);\n'
            '    FILE* f = popen(cmd, "r");\n'
            '    static char buf[4096];\n'
            '    fread(buf, 1, sizeof(buf)-1, f);\n'
            '    pclose(f);\n'
            '    return buf;\n'
            '}\n\n'
        )
        # --- System / Syscall ---
        header.write('#include <unistd.h>\n')   # para syscalls
        header.write('#include <sys/types.h>\n')
        header.write('#include <sys/wait.h>\n')
        header.write('#include <fcntl.h>\n')
        header.write('#include <errno.h>\n\n')

        # System call wrapper (executa comando shell)
        header.write('static int System(const char* cmd) {\n')
        header.write('    int ret = system(cmd);\n')
        header.write('    return ret;\n')
        header.write('}\n\n')

        # Syscall wrapper (exemplo de read/write)
        header.write('static long Syscall(long number, long arg1, long arg2, long arg3) {\n')
        header.write('    long ret = syscall(number, arg1, arg2, arg3);\n')
        header.write('    return ret;\n')
        header.write('}\n')

        # Logo após o header/preamble, antes de fwd:
        ext_buf = StringIO()
        for e in prog.externs:
            params_s = ', '.join(
                f'{self.c_type(p.type_)} {p.name}' for p in e.params
            ) or 'void'
            ret_s = self.c_type(e.ret_type)
            ext_buf.write(f'extern {ret_s} {e.name}({params_s});\n')
        if prog.externs:
            ext_buf.write('\n')
        # Forward declarations
        fwd = StringIO()
        for f in prog.funcs:
            fwd.write(self.func_signature(f) + ';\n')
        fwd.write('\n')

        # Globals
        glb = StringIO()
        for gv in prog.globals_:
            glb.write(f'/* [{gv.user_level}] */ ')
            if isinstance(gv.type_, TypeArr) and gv.type_.size is not None:
                size_s = self.gen_expr(gv.type_.size)
                inner = self.c_type(gv.type_.elem_type)
                if gv.init:
                    glb.write(f'static {inner} {gv.name}[{size_s}]')
                    glb.write(' = ' + self.gen_expr(gv.init))
                else:
                    glb.write(f'static {inner} {gv.name}[{size_s}]')
                glb.write(';\n')
            else:
                ct = self.c_type(gv.type_)
                glb.write(f'static {ct} {gv.name}')
                if gv.init:
                    glb.write(' = ' + self.gen_expr(gv.init))
                glb.write(';\n')
        if prog.globals_:
            glb.write('\n')

        # Functions
        body_buf = StringIO()
        for f in prog.funcs:
            self.out = StringIO()
            self.indent = 0
            self.gen_func(f)
            body_buf.write(self.out.getvalue())
            body_buf.write('\n')

        # String literals as globals
        str_buf = ''
        for sid, val in self.string_literals:
            escaped = val.replace('\\', '\\\\').replace('"', '\\"') \
                         .replace('\n', '\\n').replace('\t', '\\t')
            str_buf += f'static char* {sid} = "{escaped}";\n'
        if str_buf:
            str_buf += '\n'

        return header.getvalue() + ext_buf.getvalue() + fwd.getvalue() + str_buf + glb.getvalue() + body_buf.getvalue()

    # ─── Function ─────────────────────────────────────────────────────────────

    def func_signature(self, f: FuncDef) -> str:
        params = ', '.join(
            f'{self.c_type(p.type_)} {p.name}' for p in f.params
        ) or 'void'
        return f'{self.c_type(f.ret_type)} {f.name}({params})'

    def gen_func(self, f: FuncDef):
        self.emitln(f'/* func [{f.user_level}] */')
        sig = self.func_signature(f)
        self.emitln(sig + ' {')
        self.indent += 1
        self.gen_block_body(f.body)
        self.indent -= 1
        self.emitln('}')

    def gen_block_body(self, block: Block):
        self.emitln(f'/* user_ctx: {block.user_ctx} */')
        for stmt in block.stmts:
            self.gen_stmt(stmt)

    # ─── Statements ───────────────────────────────────────────────────────────

    def gen_stmt(self, stmt):
        if stmt is None:
            return

        if isinstance(stmt, VarDecl):
            self.gen_var_decl(stmt)

        elif isinstance(stmt, RetStmt):
            if stmt.value is not None:
                self.emitln(f'return {self.gen_expr(stmt.value)};')
            else:
                self.emitln('return;')

        elif isinstance(stmt, IfStmt):
            self.emitln(f'if ({self.gen_expr(stmt.cond)}) {{')
            self.indent += 1
            self.gen_block_body(stmt.then_block)
            self.indent -= 1
            if stmt.else_block:
                self.emitln('} else {')
                self.indent += 1
                if isinstance(stmt.else_block, Block):
                    self.gen_block_body(stmt.else_block)
                else:
                    self.gen_stmt(stmt.else_block)
                self.indent -= 1
            self.emitln('}')

        elif isinstance(stmt, WhileStmt):
            self.emitln(f'while ({self.gen_expr(stmt.cond)}) {{')
            self.indent += 1
            self.gen_block_body(stmt.body)
            self.indent -= 1
            self.emitln('}')

        elif isinstance(stmt, ForStmt):
            init_s = ''
            if stmt.init:
                if isinstance(stmt.init, VarDecl):
                    # inline for-init
                    ct = self.c_type(stmt.init.type_)
                    iv = f' = {self.gen_expr(stmt.init.init)}' if stmt.init.init else ''
                    init_s = f'{ct} {stmt.init.name}{iv}'
                else:
                    init_s = self.gen_expr(stmt.init)
            cond_s = self.gen_expr(stmt.cond) if stmt.cond else '1'
            step_s = self.gen_expr(stmt.step) if stmt.step else ''
            self.emitln(f'for ({init_s}; {cond_s}; {step_s}) {{')
            self.indent += 1
            self.gen_block_body(stmt.body)
            self.indent -= 1
            self.emitln('}')

        elif isinstance(stmt, MudStmt):
            self.emitln(f'/* mud → {stmt.target_user} */')
            self.emitln('{')
            self.indent += 1
            self.gen_block_body(stmt.body)
            self.indent -= 1
            self.emitln(f'}} /* end mud {stmt.target_user} */')

        elif isinstance(stmt, ExprStmt):
            self.emitln(f'{self.gen_expr(stmt.expr)};')

        elif isinstance(stmt, Block):
            self.emitln('{')
            self.indent += 1
            self.gen_block_body(stmt)
            self.indent -= 1
            self.emitln('}')

        else:
            raise CodegenError(f"Unknown stmt: {type(stmt).__name__}")

    def gen_var_decl(self, decl: VarDecl):
        comment = f'/* [{decl.user_level}] */'
        if isinstance(decl.type_, TypeArr) and decl.type_.size is not None:
            size_s = self.gen_expr(decl.type_.size)
            inner = self.c_type(decl.type_.elem_type)
            # Check if init is literal 0 (zero-init)
            from ast_nodes import IntLit
            if decl.init is None or (isinstance(decl.init, IntLit) and decl.init.value == 0):
                self.emitln(f'{comment} {inner} {decl.name}[{size_s}];')
                self.emitln(f'memset({decl.name}, 0, sizeof({decl.name}));')
            else:
                self.emitln(f'{comment} {inner} {decl.name}[{size_s}] = {self.gen_expr(decl.init)};')
        else:
            ct = self.c_type(decl.type_)
            if decl.init:
                self.emitln(f'{comment} {ct} {decl.name} = {self.gen_expr(decl.init)};')
            else:
                default = '0' if ct in ('long long', 'double') else "'\\0'"
                self.emitln(f'{comment} {ct} {decl.name} = {default};')

    # ─── Expressions ──────────────────────────────────────────────────────────

    def gen_expr(self, expr) -> str:
        if expr is None:
            return '0'

        if isinstance(expr, IntLit):
            return str(expr.value)

        if isinstance(expr, FloatLit):
            s = str(expr.value)
            if '.' not in s:
                s += '.0'
            return s

        if isinstance(expr, CharLit):
            ch = expr.value
            escapes = {'\n': '\\n', '\t': '\\t', '\r': '\\r',
                       '\\': '\\\\', "'": "\\'", '\0': '\\0'}
            return f"'{escapes.get(ch, ch)}'"

        if isinstance(expr, StringLit):
            sid = self.str_lit_id(expr.value)
            return sid

        if isinstance(expr, Ident):
            return expr.name

        if isinstance(expr, BinOp):
            l = self.gen_expr(expr.left)
            r = self.gen_expr(expr.right)
            if expr.op == '^':
                return f'pow((double)({l}), (double)({r}))'
            return f'({l} {expr.op} {r})'

        if isinstance(expr, UnaryOp):
            operand = self.gen_expr(expr.operand)
            if expr.op == '&':
                return f'(&{operand})'
            return f'({expr.op}{operand})'

        if isinstance(expr, Assign):
            t = self.gen_expr(expr.target)
            v = self.gen_expr(expr.value)
            return f'({t} = {v})'

        if isinstance(expr, Index):
            a = self.gen_expr(expr.array)
            i = self.gen_expr(expr.idx)
            return f'({a}[{i}])'

        if isinstance(expr, Call):
            args = ', '.join(self.gen_expr(a) for a in expr.args)
            return f'{expr.name}({args})'

        if isinstance(expr, Ternary):
            c = self.gen_expr(expr.cond)
            t = self.gen_expr(expr.then_expr)
            e = self.gen_expr(expr.else_expr)
            return f'({c} ? {t} : {e})'

        if isinstance(expr, FieldAccess):
            obj = self.gen_expr(expr.obj)
            return f'{obj}.{expr.field}'

        raise CodegenError(f"Unknown expr: {type(expr).__name__}")
